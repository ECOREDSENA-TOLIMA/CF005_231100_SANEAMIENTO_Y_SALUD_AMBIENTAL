function ExecuteScript(strId)
{
  switch (strId)
  {
      case "6nZ3oBTVRNP":
        Script1();
        break;
  }
}

function Script1()
{
  Window.close();
}

